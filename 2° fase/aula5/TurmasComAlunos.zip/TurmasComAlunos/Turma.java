import java.util.ArrayList;
public class Turma
{
    private String nomeDisciplina;
    private String nomeProfessor;
    private ArrayList<Aluno> aluno;
    
    public Turma(String nomeDisciplina, String nomeProfessor){
        this.nomeDisciplina = nomeDisciplina;
        this.nomeProfessor = nomeProfessor;
        this.aluno = new ArrayList<Aluno>();
    }
    
    public void addAluno(Aluno alu){
        this.aluno.add(alu);
    }
    
    public int getQuantAluno(){
        return this.aluno.size();
    }
    
    public void imprimeAlunos(){
        for (int i = 0; i<this.aluno.size(); i++){
            Aluno alu = this.aluno.get(i);
            System.out.println("teste "+alu.getMatricula() + ", " + alu.getNome());
        }
    }
}
