/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classe;

/**
 *
 * @author mateu
 */
import java.util.ArrayList;
public class ReceitaFederal
{
    private ArrayList<Pessoas> pessoas;
    
    public ReceitaFederal(){
        this.pessoas = new ArrayList<Pessoas>();
    }
    
    public void addPessoas(Pessoas umaPess){
        this.pessoas.add(umaPess);
    }
    
    public ArrayList<Pessoas> getPessoas(){
        return this.pessoas;
    }
    
    public String imprimirContribuintesDadosBasicos(){
        String texto = "";
        for(Pessoas umaPess : this.pessoas){
            texto += umaPess.toString() + "\n";
        }
        return(texto);
    }
    
    public String imprimirContribuintesCompletos(){
        String texto = "";
        for(Pessoas umaPess : this.pessoas){
            texto += umaPess.toString() + ", Imposto: " + umaPess.calcImposto() + "\n";
        }
        return(texto);
    }
}

