public class Deputado
{
    private int matricula;
    private String nome;
    private int numPart;
    private String estado;
    
    public Deputado(int matricula, String nome, String estado, int numPart){
        this.matricula = matricula;
        this.nome = nome;
        this.estado = estado;
        this.numPart = numPart;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public int getMatricula(){
        return this.matricula;
    }
    
    public String getEstado(){
        return this.estado;
    }
    
    public boolean setPartido(int numPart){
        if(numPart>0){
            this.numPart = numPart;
            return true;
        }
        else{
            return false;
        }
    }
    
    public int getPartido(){
        return this.numPart;
    }
    
    public String imprimirDeputado(){
        return "Nome: " + this.nome + ", Matricula: " + this.matricula + ", Estado: " + this.estado + ", Partido: " + this.numPart;
    }
    
}
