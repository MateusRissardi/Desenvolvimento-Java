import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class TesteSistema
{
    @Test
    public void Teste(){
        Comissao com1 = new Comissao("Comissao de Justica");
        Comissao com2 = new Comissao("Comissao do Trabalho");
        
        Deputado dep1 = new Deputado(111, "Joao", "SC", 91);
        
        
    }
}
