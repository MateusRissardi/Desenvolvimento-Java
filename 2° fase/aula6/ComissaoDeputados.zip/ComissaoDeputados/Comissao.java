import java.util.ArrayList;
public class Comissao
{
    private String titulo;
    private ArrayList<Deputado> deputado;
    public Comissao(String titulo){
        this.titulo = titulo;
        this.deputado = new ArrayList<Deputado>();
    }
    
    public void addDeputado(Deputado deputado){
        this.deputado.add(deputado);
    }
    
    public String getTitulo(){
        return this.titulo;
    }
    
    public ArrayList<Deputado> getDeputado(){
        return this.deputado;
    }
    public ArrayList<Deputado> getDeputado(int numPart){
        ArrayList<Deputado> depPart = new ArrayList<Deputado>();
        /*for(int i = 0; i<this.deputado.size(); i++){
            Deputado umDep = this.deputado.get(i);{*/
        for (Deputado umDep : this.deputado){
            if(umDep.getPartido() == numPart){
                depPart.add(umDep);
            }
        }
        return depPart;
    }
    public ArrayList<Deputado> getDeputado(String estado){
        ArrayList<Deputado> depEst = new ArrayList<Deputado>();
        /*for(int i = 0; i<this.deputado.size(); i++){
            Deputado umDep = this.deputado.get(i);{*/
        for (Deputado umDep : this.deputado){
            if(umDep.getEstado().equals(estado)){
                depEst.add(umDep);
            }
        }
        return depEst;
    }
    public void imprimirDep(){
        System.out.println(this.titulo);
        for(Deputado dep : this.deputado){
            System.out.println(dep.imprimirDeputado());
        }
    }
    public void imprimirDep(int numPart){
        ArrayList<Deputado> depPartido = this.getDeputado(numPart);
        for(Deputado dep : this.deputado){
            System.out.println(dep.imprimirDeputado());
        }
    }
    public void imprimirDep(String estado){
        ArrayList<Deputado> depPartido = this.getDeputado(estado);
        for(Deputado dep : this.deputado){
            System.out.println(dep.imprimirDeputado());
        }
    }
}
