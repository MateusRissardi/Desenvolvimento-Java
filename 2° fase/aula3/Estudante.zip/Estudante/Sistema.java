

public class Sistema
{
    public static void main (String[] args){
        Estudante est1 = new Estudante(556644);
        Estudante est2 = new Estudante(579035);
        
        est1.setNome("Fernando");        
        est1.addCreditos(36);
        
        System.out.println(est1.calcularLogin());
            
        System.out.println(est1.toString());
        
        est1.addCreditos(4);
        System.out.println(est1.toString());

        est1.setNome("Fernando Santos");
        
        System.out.println(est1.calcularLogin());
        
        System.out.println(est1.toString());
        

    }
}
