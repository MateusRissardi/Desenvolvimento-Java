public class Estudante
{
    private String nome;
    private int matricula;
    private int creditos;
    
    public Estudante (int matricula){
        this.nome = "";
        this.matricula = matricula;
        this.creditos = 0;
    }
    
    public int getMatricula (){
        return this.matricula;
    }
    
    public boolean setNome (String nome){
        if(!nome.isEmpty() && nome.length() >= 3){
            this.nome = nome;
            return true;
        }
        else{
            return false;
        }
    }
    
    public String getNome (){
        return this.nome;
    }
    
    public boolean addCreditos (int quantidade){
        if(quantidade>0){
            this.creditos += quantidade;
            return true;
        }
        else{
            return false;
        }
    }
    
    public int getCreditos (){
        return this.creditos;
    }
    
    public String calcularLogin (){
        String login = "";
        String matricString = Integer.toString(this.matricula);
        int num = matricString.length();
        login = this.nome.substring(0, 3) + matricString.substring(num-3, num);
        return login;
    }
    
    public String toString(){
        return "Nome: " + this.nome + ", Matricula: " + this.matricula + ", Login: " + calcularLogin() + ", Créditos: " + this.creditos;
    }
}
